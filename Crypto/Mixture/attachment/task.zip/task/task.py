from Crypto.Util.number import *
import random
from gmpy2 import *
from flag import flag

p = getPrime(256)
q = getPrime(256)
while p > q:
    q = getPrime(256)
n = p*q
hint1 = p^2*q

hint2 = p*q^2

print(f'hint1 = {hint1}')
print(f'hint2 = {hint2}')


s = [getPrime(512) for _ in range(2)]
a,b = getPrime(32),getPrime(32)

c = (s[0]*a**2*b + s[1]*a*b**2) % p**2 

print(f'c = {c}')
print(f's = {s}')

class LCG:
    def __init__(self, seed, a, b, m):
        self.seed = seed 
        self.a = a  
        self.b = b  
        self.m = m  

    def generate(self):
        self.seed = (self.a * self.seed + self.b) % self.m
        return self.seed


lcg = LCG(flag, a, b, q**2)

for i in range(getPrime(8)):
    lcg.generate()

print(f'x = {lcg.generate()}')