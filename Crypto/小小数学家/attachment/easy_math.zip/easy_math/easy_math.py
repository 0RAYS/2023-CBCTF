from random import *
from flag import flag
from Crypto.Util.number import *

f = lambda x, L, b: (x >> L) | ((x & ((1<<L)-1)) << (b-L))

m = bytes_to_long(flag)
n = m.bit_length()
print(f'n = {n}')
# n = 367
w = open("out.txt", 'w')
for i in range(n):
    N1 = 2*getRandomNBitInteger(200) + 1
    N2 = 2*getRandomNBitInteger(200) 
    e = randint(2**2022,2**2023)
    c = pow(f(m,i,n)*N1,e,N2)
    w.write(str(c)+'\n')



    
    
