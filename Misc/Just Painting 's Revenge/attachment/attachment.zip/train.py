import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import cv2


class JBN(nn.Module):
    '''
        JBN cruelly deleted all the content here. Maybe you can restore it, in many way.
    '''


def watch_flag(img):
    flag = cv2.imread('./data/data/flag.png')
    gray_image = cv2.cvtColor(flag, cv2.COLOR_BGR2GRAY)
    flag_tensor = torch.from_numpy(np.array(gray_image))
    flag_tensor = flag_tensor.unsqueeze(0).transpose(1, 2)
    img_tensor = img
    flag_tensor = flag_tensor.unsqueeze(0)
    img_tensor = img_tensor.unsqueeze(0)
    loss_fn = torch.nn.MSELoss()
    loss = loss_fn(flag_tensor.float(), img_tensor)
    return loss


jbn = JBN()
g_optimizer = torch.optim.Adam(jbn.parameters(), lr=0.001)
min_loss = float('inf')

for epoch in range(10):
    random_noise = torch.randn(1, 100)
    jbn_img = jbn(random_noise)
    g_optimizer.zero_grad()
    g_loss = watch_flag(jbn_img)
    g_loss.backward()
    g_optimizer.step()
    with torch.no_grad():
        if g_loss < min_loss:
            min_loss = g_loss
            torch.save(jbn.state_dict(), 'jbn.pth')
