import hashlib

game_bin_path = '../ezgame_export/ezgame.exe'
game_pck_path = '../ezgame_export/ezgame.pck'

flag = 'CBCTF{Ea5y_g0dOt_s1mpIe_game}'
flag_bin = flag.encode().ljust(32, b'\0')

def get_pck_md5() -> str:
    global game_pck_path
    h = hashlib.md5()
    h.update(open(game_pck_path, 'rb').read())
    return h.hexdigest()

def patch_bin_file(patch : bytes):
    global game_bin_path
    assert(len(patch) == 32)
    fp = open(game_bin_path, 'rb+')
    fp.seek(0x50)
    fp.write(patch)
    fp.close()

if __name__ == "__main__":
    pck_md5 = get_pck_md5()
    print('pck_md5:' + pck_md5)
    # 44957c103fadcf66aaaf6197b930bc0f

    buf = bytearray(pck_md5.encode())
    for i in range(len(buf)):
        buf[i] ^= flag_bin[i]
    
    patch_bin_file(buf)

