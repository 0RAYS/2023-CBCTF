import random

source_path = './ScoreBoard.gd'
dest_path = './ScoreBoard_shelled.gd'

sample_code = '''\
extends Node2D
func _ready():
\tprint('dynacode!')
'''

pattern = '''\
extends Label

var aaa = PackedByteArray(%s)
var bbb = PackedByteArray(%s)

func _ready():
	for i in range(aaa.size()):
		var t = aaa[i]
		aaa[i] = bbb[t]
		var w = bbb[t]
		bbb[t] = bbb[aaa[i]]
		bbb[aaa[i]] = w
	var s = GDScript.new()
	s.source_code = aaa.get_string_from_utf8()
	s.reload()
	set_script(s)
	_ready()

func _process(delta):
	_process(delta)
	
func _physics_process(delta):
	_physics_process(delta)
'''

def gen_sbox() -> list[int]:
    result = [x for x in range(256)]
    for i in range(255):
        k = random.randint(i + 1, 255)
        result[i], result[k] = result[k], result[i]
    return result

def encrypt(data : list[int], sbox : list[int]) -> list[int]:
    result = data.copy()
    buf = sbox.copy()

    for i in range(len(result)):
        t = result[i]
        result[i] = buf.index(result[i])
        buf[t], buf[result[i]] = buf[result[i]], buf[t]
    
    return result

def decrypt(data : list[int], sbox : list[int]) -> list[int]:
    result = data.copy()
    buf = sbox.copy()

    for i in range(len(result)):
        t = result[i]
        result[i] = buf[t]
        buf[t], buf[result[i]] = buf[result[i]], buf[t]
    
    return result

if __name__ == "__main__":
    sbox = gen_sbox()
    print('sbox:' + str(sbox))

    source_code = open(source_path, 'r', encoding='utf-8').read()
    source_code = list(source_code.encode())

    # res = encrypt(sample_code, sbox)
    res = encrypt(source_code, sbox)
    print('encrypted:' + str(res))

    open(dest_path, 'w').write(pattern % (res, sbox))

    conf = decrypt(res, sbox)
    print('decrypted:' + str(bytes(conf)))