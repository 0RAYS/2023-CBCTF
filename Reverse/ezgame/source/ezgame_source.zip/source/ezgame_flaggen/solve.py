import hashlib

game_bin_path = '../ezgame_export/ezgame.exe'
game_pck_path = '../ezgame_export/ezgame.pck'

def get_pck_md5() -> str:
    global game_pck_path
    h = hashlib.md5()
    h.update(open(game_pck_path, 'rb').read())
    return h.hexdigest()

def get_key_from_bin_file() -> bytes:
    global game_bin_path
    fp = open(game_bin_path, 'rb')
    fp.seek(0x50)
    return fp.read(0x20)

def get_flag() -> bytearray:
    data = bytearray(get_pck_md5().encode())
    key = get_key_from_bin_file()
    for i in range(len(data)):
        data[i] ^= key[i]
    return data

if __name__ == "__main__":
    flag = get_flag()
    print(flag)