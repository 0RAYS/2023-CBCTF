ezgame文件夹内有godot project源码。godot编辑器版本4.1.2 - stable。
该项目已应用反调试特性，所以在编辑器内通常无法启动。

ezgame_flaggen文件夹包含flag生成脚本以及解题脚本。
·make_shell.py用于为GDS代码加壳（或者说转化为shellcode），源代码是ScoreBoard.gd
·flaggen.py用于根据flag生成key，并将key二进制覆盖到ezgame.exe
·unpack_shell.py用于还原ScoreBoard.gd
·solve.py是解题脚本

ezgame_export文件夹有游戏的导出样本。

ezgame_unpack文件夹是GDRE的解包结果。